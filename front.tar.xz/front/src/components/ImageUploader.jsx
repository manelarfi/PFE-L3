import React, { useRef, useState } from 'react';

const ImageUploader = ({ onImageSelect }) => {
  const fileInputRef = useRef(null);
  const [preview, setPreview] = useState(null);

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      onImageSelect(file);
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      setPreview(previewUrl);
    }
  };

  return (
    <div className="image-uploader">
      {preview ? (
        <div className="preview-container">
          <img src={preview} alt="Preview" className="image-preview" />
          <button className="change-image" onClick={handleButtonClick}>
            Change Image
          </button>
        </div>
      ) : (
        <button className="image-up" onClick={handleButtonClick}>+</button>
      )}
      <input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        ref={fileInputRef}
        style={{ display: 'none' }}
      />
    </div>
  );
};

export default ImageUploader;
