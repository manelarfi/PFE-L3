import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import ImageUploader from "./ImageUploader.jsx";
import TextBox from "./TextContainer.jsx";

function HideContainer() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleImageSelect = (file) => {
    setSelectedImage(file);
    setError(null);
  };

  const handleTextSubmit = (text) => {
    setMessage(text);
    setError(null);
  };

  const handleEncode = async () => {
    if (!selectedImage || !message) {
      setError("Please select both an image and enter a message");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('image', selectedImage);
      formData.append('message', message);

      const response = await fetch('http://127.0.0.1:5000/api/steganography/dwt/encode', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to encode message');
      }

      // Get the image blob from response
      const imageBlob = await response.blob();
      const imageUrl = URL.createObjectURL(imageBlob);

      // Navigate to results with the image URL
      navigate('/results-hide', {
        state: {
          encodedImage: imageUrl,
          originalText: message,
          isBlob: true
        }
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="hide-container">
      <h1 className="hide">Hide your text</h1>
      <div className="container">
        <div className="image-section">
          <h2 className="container-title">Add Your Cover Image</h2>
          <ImageUploader onImageSelect={handleImageSelect} />
        </div>
        <div className="text-section">
          <h2 className="container-text-title">Add Your Text</h2>
          <TextBox onTextSubmit={handleTextSubmit} />
        </div>
        {error && <div className="error-message">{error}</div>}
        <button
          className="encode-button"
          onClick={handleEncode}
          disabled={isLoading || !selectedImage || !message}
        >
          {isLoading ? 'Processing...' : 'Hide Message'}
        </button>
      </div>
    </div>
  );
}

export default HideContainer;